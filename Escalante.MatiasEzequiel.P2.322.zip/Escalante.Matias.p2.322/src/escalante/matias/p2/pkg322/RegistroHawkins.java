/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package escalante.matias.p2.pkg322;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 *
 * @author NoxiePC
 */
public class RegistroHawkins<T extends CSVSerializable> {

    private List<T> casos = new ArrayList<>();

    private void checkNull(Object o) {
        if (o == null) {
            throw new NullPointerException("Elemento nulo");
        }
    }

    private void validarIndice(int indice) {
        if (indice > casos.size() && indice < 0) {
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }

    public void agregar(T caso) {
        checkNull(casos);
        casos.add(caso);
    }

    public boolean eliminar(int indice) {
        return casos.remove(obtenerElemento(indice));
    }

    public T obtenerElemento(int indice) {
        validarIndice(indice);
        return casos.get(indice);
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> filtrado = new ArrayList<>();
        for (T t : casos) {
            if (criterio.test(t)) {
                filtrado.add(t);
            }
        }
        return filtrado;
    }
    public void paraCadaElemento(Consumer<? super T> accion) {
        casos.forEach(accion::accept);
    }
    
    public void ordenarNatural() {
        if ((casos.isEmpty() && casos.get(0) instanceof Comparable)) {
            throw new UnsupportedOperationException("Los elementos no son comparables");
        } else {
            Collections.sort((List) casos);
        }
    }

    public void ordenar(Comparator<T> cmp) {
        Collections.sort(casos, cmp);
    }

    public void GuardarEnCSV(String path) {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {

            for (T caso : casos) {
                escritor.write(caso.toCSV());
                escritor.newLine();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public void cargarDesdeCSV(String path) {
        casos.clear();
        try (BufferedReader velocista = new BufferedReader(new FileReader(path))) {
            String linea;
            velocista.readLine();
            while ((linea = velocista.readLine()) != null) {
                CasoHawkins caso = CasoHawkins.fromCSV(linea);
                casos.add((T) caso);
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void guardarEnArchivo(String path) {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            Iterator<T> it = casos.iterator();
            while (it.hasNext()) {
                T pelicula = it.next();
                serializador.writeObject(pelicula);
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void cargarDesdeArchivo(String path) {
        casos.clear();
        try (ObjectInputStream des = new ObjectInputStream(new FileInputStream(path))) {
            while (true) {
                try {
                    T pelicula = (T) des.readObject();
                    casos.add(pelicula);
                } catch (EOFException ex) {
                    System.out.println(ex.getMessage());
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
