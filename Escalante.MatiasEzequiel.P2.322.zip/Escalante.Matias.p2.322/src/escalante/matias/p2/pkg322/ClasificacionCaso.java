/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package escalante.matias.p2.pkg322;

/**
 *
 * @author NoxiePC
 */
public enum ClasificacionCaso {
    APERTURA_DIMENSIONAL,
    SUJETO_PSIQUICO,
    ENTIDAD_HOSTIL,
    FENOMENO_ELECTROMAGNETICO,
    DESAPARICION,
    CONFIDENCIAL
}
