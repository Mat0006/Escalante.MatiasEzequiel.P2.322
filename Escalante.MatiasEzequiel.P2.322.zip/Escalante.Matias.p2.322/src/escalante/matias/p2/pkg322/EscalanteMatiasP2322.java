/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package escalante.matias.p2.pkg322;

import java.io.IOException;

/**
 *
 * @author NoxiePC
 */
public class EscalanteMatiasP2322 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>();
            registro.agregar(new CasoHawkins(2, "Actividad psíquica elevada", "Dr.Owens", ClasificacionCaso.SUJETO_PSIQUICO));
            registro.agregar(new CasoHawkins(4, "Señales electromagnéticas inusuales", "Nancy Wheeler", ClasificacionCaso.FENOMENO_ELECTROMAGNETICO));
            registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr.Brenner", ClasificacionCaso.APERTURA_DIMENSIONAL));
            registro.agregar(new CasoHawkins(5, "Desaparición de joven en bosque", "Joyce Byers", ClasificacionCaso.DESAPARICION));
            registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "JimHopper", ClasificacionCaso.ENTIDAD_HOSTIL));

            System.out.println("Casos Registrados");
            registro.paraCadaElemento(p -> System.out.println(p));

            System.out.println("\nCasos tipo SUJETO_PSIQUICO");
            registro.filtrar(p -> p.getClasificacion() == ClasificacionCaso.SUJETO_PSIQUICO)
                    .forEach(System.out::println);

            System.out.println("\nCasos que tienen 'portal'");
            registro.filtrar(p -> p.getTitulo().contains("portal"))
                    .forEach(System.out::println);

            System.out.println("\nCasos ordenados por ID");
            registro.ordenar((c1, c2) -> Integer.compare(c1.getId(), c2.getId()));
            registro.paraCadaElemento(p -> System.out.println(p));

            registro.guardarEnArchivo("src/data/casos.dat");

            RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>();
            cargado.cargarDesdeArchivo("src/data/casos.dat");
            System.out.println("\nCasos cargados desde archivo binario");
            cargado.paraCadaElemento(p -> System.out.println(p));

            registro.GuardarEnCSV("src/data/casos.csv");

            cargado.cargarDesdeCSV("src/data/casos.csv");

            System.out.println("\n Casos cargados desde archivo CSV");
            cargado.paraCadaElemento(p -> System.out.println(p));
    }
}
